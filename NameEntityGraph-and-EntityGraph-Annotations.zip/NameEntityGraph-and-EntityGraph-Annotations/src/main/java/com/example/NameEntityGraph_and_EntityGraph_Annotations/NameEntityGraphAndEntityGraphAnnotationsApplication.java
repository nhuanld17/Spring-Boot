package com.example.NameEntityGraph_and_EntityGraph_Annotations;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NameEntityGraphAndEntityGraphAnnotationsApplication {

	public static void main(String[] args) {
		SpringApplication.run(NameEntityGraphAndEntityGraphAnnotationsApplication.class, args);
	}

}
