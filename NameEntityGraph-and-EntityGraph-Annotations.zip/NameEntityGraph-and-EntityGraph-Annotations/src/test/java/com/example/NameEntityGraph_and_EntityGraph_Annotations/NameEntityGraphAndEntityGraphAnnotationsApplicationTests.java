package com.example.NameEntityGraph_and_EntityGraph_Annotations;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NameEntityGraphAndEntityGraphAnnotationsApplicationTests {

	@Test
	void contextLoads() {
	}

}
